package com.springboot.question9.service;

import com.springboot.question9.dto.PostDto;
import com.springboot.question9.dto.PostResponse;

import java.util.List;

public interface PostService {
	PostDto createPost(PostDto postDto);

    PostResponse getAllPosts(int pageNo, int pageSize, String sortBy, String sortDir);

}
