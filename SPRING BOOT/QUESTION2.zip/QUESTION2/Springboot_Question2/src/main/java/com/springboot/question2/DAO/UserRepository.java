package com.springboot.question2.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question2.model.User;

public interface UserRepository extends JpaRepository<User, Long> {

}
