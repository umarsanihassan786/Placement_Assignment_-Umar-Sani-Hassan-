package com.springboot.question2.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springboot.question2.DAO.OrderRepository;
import com.springboot.question2.model.Order;
import com.springboot.question2.model.User;

@Service
public class OrderService {
	private final OrderRepository orderRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    public List<Order> getOrdersByUser(User user) {
        return orderRepository.findByUser(user);
    }

}
