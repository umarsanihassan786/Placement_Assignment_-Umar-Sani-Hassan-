package com.springboot.question6.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.question6.DAO.ProductDAO;
import com.springboot.question6.model.Product;

@Service
public class ProductService {
	
	private final ProductDAO productDAO;
	
	public ProductService(ProductDAO productDAO) {
        this.productDAO = productDAO;
    }
	
	public List<Product> getAllProducts() {
        return productDAO.findAll();
    }
	
	public Product createProduct( Product product) {
        Product createdProduct = productDAO.save(product);
        return createdProduct;
    }
	
	public Product getProductById(Long id) {
        Product product = productDAO.findById(id).orElse(null);
        if (product == null) {
            return null;
        }
        return product;
    }
	
	public Product updateProduct(Long id, Product product) {
        if (!productDAO.existsById(id)) {
            return null;
        }
        product.setId(id);
        Product updatedProduct = productDAO.save(product);
        return updatedProduct;
    }
	
	public Product deleteProduct(Long id) {
		 Product product = productDAO.findById(id).orElse(null);
	        if (product == null) {
	            return null;
	        }
        productDAO.deleteById(id);
        return product;
    }

}
