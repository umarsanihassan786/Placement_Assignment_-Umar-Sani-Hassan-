package com.springboot.question6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootQuestion6Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootQuestion6Application.class, args);
	}

}
