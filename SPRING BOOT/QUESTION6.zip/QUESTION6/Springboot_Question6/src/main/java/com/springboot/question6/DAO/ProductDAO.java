package com.springboot.question6.DAO;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question6.model.Product;

public interface ProductDAO extends JpaRepository<Product, Long>{

}
