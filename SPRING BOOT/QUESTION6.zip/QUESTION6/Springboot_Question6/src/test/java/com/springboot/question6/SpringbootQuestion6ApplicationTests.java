package com.springboot.question6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootQuestion6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
