package com.springboot.question5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootQuestion5Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootQuestion5Application.class, args);
	}

}
