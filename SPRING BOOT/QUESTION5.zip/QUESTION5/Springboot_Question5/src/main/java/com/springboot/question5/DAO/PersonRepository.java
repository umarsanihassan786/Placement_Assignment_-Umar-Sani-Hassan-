package com.springboot.question5.DAO;
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question5.model.Person;

public interface PersonRepository extends JpaRepository<Person, Long>{


}
