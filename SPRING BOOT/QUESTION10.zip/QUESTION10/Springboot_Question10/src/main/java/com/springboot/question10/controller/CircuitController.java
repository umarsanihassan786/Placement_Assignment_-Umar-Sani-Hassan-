package com.springboot.question10.controller;

import java.util.ArrayList;
import java.util.List;
import com.springboot.question10.model.Person;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;


@RestController
public class CircuitController {
	
	@Autowired
	private RestTemplate restTemplate;
	
	
	@GetMapping("/api")
	@CircuitBreaker(name = "Personbreaker", fallbackMethod = "PersonFallBackMethod")
	public List<Person> getPerson(){
		List<Person> person = restTemplate.getForObject("http://localhost:8087/allPersons", List.class);
		return person;
    }
	
	public List<Person> PersonFallBackMethod(){
		
		List<Person> person = new ArrayList<>();
		Person persons = new Person();
		persons.setId(new Long(3333333));
		persons.setName("fallbackmethod is used");
		person.add(persons);
		return null;
		
	}

}
