package com.springboot.question10;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootQuestion10Application {

	public static void main(String[] args) {
//		
		SpringApplication.run(SpringbootQuestion10Application.class, args);
	}

}
