package com.springboot.question1.DAO;
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question1.model.Person;

public interface PersonRepository extends JpaRepository<Person, Long>{


}
