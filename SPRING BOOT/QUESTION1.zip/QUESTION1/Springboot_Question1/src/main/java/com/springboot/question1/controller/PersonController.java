package com.springboot.question1.controller;

import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.question1.model.Person;
import com.springboot.question1.service.PersonService;

@RestController
public class PersonController {
	
	private final PersonService personService;

    public PersonController(PersonService personService) {
        this.personService = personService;
    }

    @PostMapping("/person")
    public void insertPerson(@RequestBody String name) {
        personService.insertPerson(name);
    }
    
    @GetMapping("/allPersons")
    public List<Person> getPerson(){
    	return personService.getPerson();
    }

}
