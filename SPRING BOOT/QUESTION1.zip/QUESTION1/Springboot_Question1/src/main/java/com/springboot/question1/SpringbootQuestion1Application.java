package com.springboot.question1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.springboot.question1.DAO.PersonRepository;
import com.springboot.question1.model.Person;

@SpringBootApplication
public class SpringbootQuestion1Application {

	public static void main(String[] args) {
		ApplicationContext context = SpringApplication.run(SpringbootQuestion1Application.class, args);
		
		
	}

}
