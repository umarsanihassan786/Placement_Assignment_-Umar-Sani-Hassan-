package com.springboot.question8_configServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@EnableDiscoveryClient
@EnableConfigServer
@SpringBootApplication
public class SpringbootQuestion8ConfigServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootQuestion8ConfigServerApplication.class, args);
	}

}
