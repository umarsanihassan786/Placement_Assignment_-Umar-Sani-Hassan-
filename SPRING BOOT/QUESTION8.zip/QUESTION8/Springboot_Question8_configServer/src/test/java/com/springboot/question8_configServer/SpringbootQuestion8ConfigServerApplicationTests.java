package com.springboot.question8_configServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootQuestion8ConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
