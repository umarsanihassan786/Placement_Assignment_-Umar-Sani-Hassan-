package com.springboot.question3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question3.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {

    Role findByName(String name);
}
