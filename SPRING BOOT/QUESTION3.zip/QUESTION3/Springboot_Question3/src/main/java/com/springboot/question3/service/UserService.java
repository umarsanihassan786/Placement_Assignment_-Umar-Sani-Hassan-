package com.springboot.question3.service;

import java.util.List;

import com.springboot.question3.dto.UserDto;
import com.springboot.question3.entity.User;

public interface UserService {
    void saveUser(UserDto userDto);

    User findUserByEmail(String email);

    List<UserDto> findAllUsers();
}