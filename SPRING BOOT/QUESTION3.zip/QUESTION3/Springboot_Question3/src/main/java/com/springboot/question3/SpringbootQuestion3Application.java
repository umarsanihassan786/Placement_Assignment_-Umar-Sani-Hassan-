package com.springboot.question3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootQuestion3Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootQuestion3Application.class, args);
	}

}
