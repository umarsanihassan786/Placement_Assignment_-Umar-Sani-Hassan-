package com.springboot.question3.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question3.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {

    User findByEmail(String email);

}