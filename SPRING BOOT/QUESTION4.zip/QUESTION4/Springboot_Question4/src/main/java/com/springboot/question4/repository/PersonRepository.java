package com.springboot.question4.repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.question4.model.Person;

public interface PersonRepository extends JpaRepository<Person, Long>{


}
