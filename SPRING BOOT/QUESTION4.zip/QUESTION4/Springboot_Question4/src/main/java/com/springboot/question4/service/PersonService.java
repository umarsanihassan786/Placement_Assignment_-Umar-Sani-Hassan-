package com.springboot.question4.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.springboot.question4.repository.PersonRepository;
import com.springboot.question4.model.Person;

@Service
public class PersonService {
	 private final PersonRepository personRepository;

	    public PersonService(PersonRepository personRepository) {
	        this.personRepository = personRepository;
	    }

	    public void insertPerson(String name) {
	        Person person = new Person();
	        person.setName(name);
	        personRepository.save(person);
	    }
	    
	    public List<Person> getPerson(){
	    	return personRepository.findAll();
	    }

}
