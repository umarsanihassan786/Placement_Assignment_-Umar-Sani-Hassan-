package com.springboot.question4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootQuestion4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
