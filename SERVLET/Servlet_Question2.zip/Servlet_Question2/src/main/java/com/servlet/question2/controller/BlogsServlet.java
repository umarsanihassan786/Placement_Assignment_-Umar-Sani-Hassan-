package com.servlet.question2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.servlet.question2.DAO.BlogsDao;
import com.servlet.question2.model.Blogs;

@WebServlet("/register")
public class BlogsServlet extends HttpServlet{
	private static final long serialVersionUID = 1L;
    private BlogsDao blogsDao;

    public void init() {
    	blogsDao = new BlogsDao();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {

        String id = request.getParameter("id");
        String title = request.getParameter("title");
        String description = request.getParameter("description");
        String content = request.getParameter("content");
        String address = request.getParameter("address");
        String contact = request.getParameter("contact");

        Blogs blogs = new Blogs();
        blogs.setID(Integer.parseInt(id));
        blogs.setTitle(title);
        blogs.setDescription(description);
        blogs.setContent(content);

        try {
        	blogsDao.registerBlogs(blogs);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

        response.sendRedirect("employeedetails.jsp");
    }

}
