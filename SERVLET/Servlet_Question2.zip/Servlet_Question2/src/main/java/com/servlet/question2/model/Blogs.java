package com.servlet.question2.model;

import java.io.Serializable;

public class Blogs implements Serializable{
	
	private static final long serialVersionUID = 1L;
	private int id;
    private String title;
    private String description;
    private String content;
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public int getID() {
        return id;
    }
    public void setID(int id) {
        this.id = id;
    }

}
