package com.servlet.question1;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class UserServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        // Get the current session or create a new one if it doesn't exist
        HttpSession session = request.getSession(true);
        
        // Get the user's name from the request parameter
        String name = request.getParameter("name");
        
        // Store the user's name in the session object
        session.setAttribute("name", name);
        
        // Set the response content type
        response.setContentType("text/html");
        
        // Display the user's name on the current page
        response.getWriter().println("<h1>Welcome, " + name + "!</h1>");
        
        // Provide a link to another page to display the user's name
        response.getWriter().println("<a href=\"anotherpage\">Go to another page</a>");
    }
    
}

