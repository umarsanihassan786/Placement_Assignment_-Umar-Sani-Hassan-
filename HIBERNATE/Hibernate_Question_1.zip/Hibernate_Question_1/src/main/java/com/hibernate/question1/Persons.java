package com.hibernate.question1;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Persons")
public class Persons {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int personID;
    private String firstName; 
    private String lastName; 
    private String mobileNo; 
    private String aadharNo;
    private String address;
    
    public void setID(int personID) {
    	this.personID = personID;
    }
    
    public int getId() {
    	return this.personID;
    }
    
    public void setFirstName(String firstName) {
    	this.firstName = firstName;
    }
    
    public String getFirstName() {
    	return this.firstName;
    }
    
    public void setlastName(String lastName) {
    	this.lastName = lastName;
    }
    
    public String getlastName() {
    	return this.lastName;
    }
    
    public void setMobileNo(String mobileNo) {
    	this.mobileNo =  mobileNo;
    }
    
    public String getMobileNo() {
    	return this.mobileNo;
    }
    
    public void setAadharNo(String aadharNo) {
    	this.aadharNo = aadharNo;
    }
    
    public String getAadharNo() {
    	return this.aadharNo;
    }
    
    public void setAddress(String address) {
    	this.address = address;
    }
    
    public String getAddress() {
    	return this.address;
    }

}
