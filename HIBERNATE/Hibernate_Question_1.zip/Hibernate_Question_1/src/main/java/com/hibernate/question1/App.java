package com.hibernate.question1;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	// Create a Hibernate configuration
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml"); // Assuming the configuration file is named "hibernate.cfg.xml"

        // Create a session factory
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Open a session from the session factory
        Session session = sessionFactory.openSession();

        // Retrieve data from the table using Hibernate
        List<Persons> persons = session.createQuery("FROM Persons", Persons.class).list();
        System.out.println(persons);

        // Display the retrieved data
        for (Persons person : persons) {
            System.out.println("ID: " + person.getId());
            System.out.println("First Name: " + person.getFirstName());
            System.out.println("Last Name:" + person.getlastName());
            System.out.println("Mobile No: " + person.getMobileNo());
            System.out.println("Aadhar Card: " + person.getAadharNo());
            System.out.println("Address: " + person.getAddress());
            System.out.println();
        }

        // Close the session
        session.close();

        // Close the session factory
        sessionFactory.close();
    }
    
}
