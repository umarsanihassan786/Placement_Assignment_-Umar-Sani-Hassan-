package com.hibernate.question2;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        // Create configuration instance and build the session factory
        Configuration configuration = new Configuration().configure();
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Obtain a session from the session factory
        Session session = sessionFactory.openSession();

        // Create a new employee
        Employee employee = new Employee(1,"John Doe", 30);

        // Perform database operations
        Transaction transaction = session.beginTransaction();
        Integer x = (Integer) session.save(employee); // Insert the employee into the database
        transaction.commit();

        // Retrieve the employee from the database
        Employee retrievedEmployee = session.get(Employee.class, employee.getID());

        // Display the retrieved employee on the console
        System.out.println("Retrieved Employee:");
        System.out.println("ID: " + retrievedEmployee.getID());
        System.out.println("Name: " + retrievedEmployee.getName());
        System.out.println("Age: " + retrievedEmployee.getAge());

        // Close the session and the session factory
        session.close();
        sessionFactory.close();
    }
}
