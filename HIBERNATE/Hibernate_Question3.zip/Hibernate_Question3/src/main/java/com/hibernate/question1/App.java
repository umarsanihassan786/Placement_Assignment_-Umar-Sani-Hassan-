package com.hibernate.question1;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.hibernate.question1.Employee;

/**
 * Hello world!
 *
 */
public class App 
{
	private static SessionFactory factory; 
    public static void main( String[] args )
    {
    	try {
            factory = new Configuration().configure().buildSessionFactory();
         } catch (Throwable ex) { 
            System.err.println("Failed to create sessionFactory object." + ex);
            throw new ExceptionInInitializerError(ex); 
         }
    	
    	ManageEmployee employee = new ManageEmployee();
    	
    	Integer employee1 = employee.addEmployee("Umar", 24, factory);
    	Integer employee2 = employee.addEmployee("zishan", 62, factory);
    	Integer employee3 = employee.addEmployee("tahseen", 25, factory);
    	
    	employee.listEmployees(factory);

        /* Update employee's records */
        employee.updateEmployee(1, 52, factory);

        /* Delete an employee from the database */
        employee.deleteEmployee(2, factory);

        /* List down new list of the employees */
        employee.listEmployees(factory);
    	
    }
    
}
