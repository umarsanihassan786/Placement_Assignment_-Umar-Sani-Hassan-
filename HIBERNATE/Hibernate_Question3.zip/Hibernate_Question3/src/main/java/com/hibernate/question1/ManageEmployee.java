package com.hibernate.question1;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class ManageEmployee {
	
	 public Integer addEmployee(String name, int age, SessionFactory factory){
	        Session session = factory.openSession();
	        Transaction tx = null;
	        Integer employeeID = null;
	        
	        try {
	           tx = session.beginTransaction();
	           Employee employee = new Employee(name, age);
	           employeeID = (Integer) session.save(employee); 
	           tx.commit();
	        } catch (HibernateException e) {
	           if (tx!=null) tx.rollback();
	           e.printStackTrace(); 
	        } finally {
	           session.close(); 
	        }
	        return employeeID;
	     }
	    
	    public void listEmployees( SessionFactory factory){
	        Session session = factory.openSession();
	        Transaction tx = null;
	        
	        try {
	           tx = session.beginTransaction();
	           List employees = session.createQuery("FROM Employee").list(); 
	           for (Iterator iterator = employees.iterator(); iterator.hasNext();){
	              Employee employee = (Employee) iterator.next(); 
	              System.out.print("Name: " + employee.getName()); 
	              System.out.println("  Age: " + employee.getAge()); 
	           }
	           tx.commit();
	        } catch (HibernateException e) {
	           if (tx!=null) tx.rollback();
	           e.printStackTrace(); 
	        } finally {
	           session.close(); 
	        }
	     }
	    
	    public void updateEmployee(Integer EmployeeID, int age , SessionFactory factory){
	        Session session = factory.openSession();
	        Transaction tx = null;
	        
	        try {
	           tx = session.beginTransaction();
	           Employee employee = (Employee)session.get(Employee.class, EmployeeID); 
	           employee.setAge(age);
	  		 session.update(employee); 
	           tx.commit();
	        } catch (HibernateException e) {
	           if (tx!=null) tx.rollback();
	           e.printStackTrace(); 
	        } finally {
	           session.close(); 
	        }
	     }
	    
	    public void deleteEmployee(Integer EmployeeID, SessionFactory factory){
	        Session session = factory.openSession();
	        Transaction tx = null;
	        
	        try {
	           tx = session.beginTransaction();
	           Employee employee = (Employee)session.get(Employee.class, EmployeeID); 
	           session.delete(employee); 
	           tx.commit();
	        } catch (HibernateException e) {
	           if (tx!=null) tx.rollback();
	           e.printStackTrace(); 
	        } finally {
	           session.close(); 
	        }
	     }

}
