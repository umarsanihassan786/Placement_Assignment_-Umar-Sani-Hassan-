package com.jdbc.question3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Main {

	public static void main(String[] args) {
		String jdbcURL = "jdbc:postgresql://localhost:5432/mydatabase";
        String username = "postgres";
        String password = "Umar@9525v2";
        String inputFile = "C:\\Users\\hp\\Downloads\\data.csv"; // Path to your input data file

        try {
            // Load the PostgreSQL JDBC driver
            Class.forName("org.postgresql.Driver");

            // Establish a connection to the database
            Connection connection = DriverManager.getConnection(jdbcURL, username, password);

            // Create a prepared statement with the SQL query
            String sql = "INSERT INTO user (id, name, address) VALUES (?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);

            // Read the input data from the file
            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            String line;
            while ((line = reader.readLine()) != null) {
                // Split the line into separate values
                String[] values = line.split(",");

                // Set the parameter values for the prepared statement
                statement.setString(1, values[0]);
                statement.setString(2, values[1]);
                statement.setString(3, values[2]);

                // Add the statement to the batch
                statement.addBatch();
            }
            reader.close();

            // Execute the batch update
            int[] updateCounts = statement.executeBatch();

            // Print the number of rows affected for each statement
            for (int count : updateCounts) {
                System.out.println("Rows affected: " + count);
            }

            // Close the statement and the database connection
            statement.close();
            connection.close();
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

	}

}
