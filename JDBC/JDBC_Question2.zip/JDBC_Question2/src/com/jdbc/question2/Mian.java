package com.jdbc.question2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Mian {

	// Database credentials
    static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost:3306/java_freshers";
    static final String USER = "root";
    static final String PASS = "Umar@9525v2";
	
	public static void main(String[] args) {

	        Connection conn = null;
	        Statement stmt = null;
	        try {
	            // Register JDBC driver
	            Class.forName(JDBC_DRIVER);

	            // Open a connection
	            System.out.println("Connecting to database...");
	            conn = DriverManager.getConnection(DB_URL, USER, PASS);

	            // Create a statement
	            stmt = conn.createStatement();

	            // Add a record
	            System.out.println("Adding a record...");
	            String addQuery = "INSERT INTO Persons (PersonId, Firstname, Lastname, MobileNo, AadharNo, Address) VALUES ('79', 'john', 'doe', '9900887766', '123456789456', 'tikiapara')";
	            stmt.executeUpdate(addQuery);

	            // View all records
	            System.out.println("Viewing all records...");
	            String viewQuery = "SELECT * FROM Persons";
	            ResultSet rs = stmt.executeQuery(viewQuery);
	            while (rs.next()) {
	            	 int id = rs.getInt("PersonId");
	                 String firstName = rs.getString("Firstname");
	                 String lastName = rs.getString("Lastname");
	                 String mobileNo = rs.getString("MobileNo");
	                 String aadharNo = rs.getString("AadharNo");
	                 String address = rs.getString("Address");

	                 System.out.println("ID: " + id + ", First Name: " + firstName + ", Last Name: " + lastName + " , Mobile : " + mobileNo + ", Aadhar No : " + aadharNo + ", Address : " + address);
	                 System.out.println("-------------------------");
	            }
	            rs.close();

	            // Update a record
	            System.out.println("Updating a record...");
	            String updateQuery = "UPDATE Persons SET Firstname = 'Smith' WHERE PersonId = 1";
	            stmt.executeUpdate(updateQuery);

	            // Delete a record
	            System.out.println("Deleting a record...");
	            String deleteQuery = "DELETE FROM Persons WHERE PersonId = 2";
	            stmt.executeUpdate(deleteQuery);

	            // Clean-up environment
	            stmt.close();
	            conn.close();
	        } catch (SQLException se) {
	            se.printStackTrace();
	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            try {
	                if (stmt != null)
	                    stmt.close();
	            } catch (SQLException se2) {
	            }
	            try {
	                if (conn != null)
	                    conn.close();
	            } catch (SQLException se) {
	                se.printStackTrace();
	            }
	        }
	        System.out.println("Program completed.");

	}

}
