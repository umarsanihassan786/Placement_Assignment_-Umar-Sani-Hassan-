package com.jdbc.question1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

	public static void main(String[] args) {
		 // Database connection parameters
        String url = "jdbc:mysql://localhost:3306/java_freshers";
        String username = "root";
        String password = "Umar@9525v2";

        // SQL query
        String query = "SELECT * FROM Persons";

        try {
            // Register the MySQL JDBC driver
            Class.forName("com.mysql.jdbc.Driver");

            // Create a connection to the database
            Connection conn = DriverManager.getConnection(url, username, password);

            // Create a statement
            Statement stmt = conn.createStatement();
//PersonId, Firstname, Lastname, MobileNo, AadharNo, Address
            // Execute the query
            ResultSet rs = stmt.executeQuery(query);

            // Process the result set
            while (rs.next()) {
                int id = rs.getInt("PersonId");
                String firstName = rs.getString("Firstname");
                String lastName = rs.getString("Lastname");
                String mobileNo = rs.getString("MobileNo");
                String aadharNo = rs.getString("AadharNo");
                String address = rs.getString("Address");
                // Display the retrieved data
                System.out.println("ID: " + id + ", First Name: " + firstName + ", Last Name: " + lastName + " , Mobile : " + mobileNo + ", Aadhar No : " + aadharNo + ", Address : " + address);
            }

            // Close the resources
            rs.close();
            stmt.close();
            conn.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
  
	}

}
