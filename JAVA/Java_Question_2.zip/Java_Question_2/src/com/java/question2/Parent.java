package com.java.question2;

public class Parent {

	public Parent() {
		 System.out.println("Parent class constructor invoked");
	}

}
