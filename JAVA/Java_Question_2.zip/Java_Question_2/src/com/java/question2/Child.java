package com.java.question2;

public class Child extends Parent{

	public Child() {
		 super(); // invoking parent class constructor
	        System.out.println("Child class constructor invoked");
	}

}
