package com.java.question3_withException;

class MyException extends Exception
{
 public MyException(String str)
 {
  System.out.println(str);
 }
}