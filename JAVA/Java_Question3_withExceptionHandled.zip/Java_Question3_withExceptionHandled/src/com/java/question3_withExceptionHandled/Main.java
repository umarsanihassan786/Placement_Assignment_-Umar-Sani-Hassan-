package com.java.question3_withExceptionHandled;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) throws Exception {
		
		try (Scanner sc = new Scanner(System.in)) {
			int num = sc.nextInt();
			   if(num < 0)
			    throw new MyException("Number is negative");
		}
		catch (MyException m) {
			   System.out.println(m);
		  }

	}

}
