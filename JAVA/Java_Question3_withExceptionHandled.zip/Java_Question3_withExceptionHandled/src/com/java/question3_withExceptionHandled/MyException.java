package com.java.question3_withExceptionHandled;

class MyException extends Exception
{
 public MyException(String str)
 {
  System.out.println(str);
 }
}