package com.java.question9;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;

public class Main {

	private static final int MAX_QUEUE_SIZE = 10;
	private static final int NUM_VALUES_TO_PRODUCE = 20;

	private static Queue<Integer> queue = new LinkedList<>();
	private static Object lock = new Object();
	private static int sum = 0;

	public static void main(String[] args) {
		Thread producerThread = new Thread(() -> {
			Random random = new Random();
			for (int i = 0; i < NUM_VALUES_TO_PRODUCE; i++) {
				int value = random.nextInt(100);
				produce(value);
			}
		});

		Thread consumerThread = new Thread(() -> {
			for (int i = 0; i < NUM_VALUES_TO_PRODUCE; i++) {
				int value = consume();
				calculateSum(value);
			}
		});

		producerThread.start();
		consumerThread.start();

		try {
			producerThread.join();
			consumerThread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println("Sum: " + sum);

	}

	private static void produce(int value) {
		synchronized (lock) {
			while (queue.size() == MAX_QUEUE_SIZE) {
				try {
					lock.wait(); // Wait until there is space in the queue
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			queue.add(value);
			System.out.println("Produced: " + value);
			lock.notifyAll(); // Notify the consumer thread that a value is added
		}
	}

	private static int consume() {
		synchronized (lock) {
			while (queue.isEmpty()) {
				try {
					lock.wait(); // Wait until there is a value in the queue
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}

			int value = queue.poll();
			System.out.println("Consumed: " + value);
			lock.notifyAll(); // Notify the producer thread that a value is consumed
			return value;
		}
	}

	private static void calculateSum(int value) {
		synchronized (lock) {
			sum += value;
		}
	}
}
