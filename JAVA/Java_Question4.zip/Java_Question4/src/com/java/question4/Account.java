package com.java.question4;

public class Account {
	
	    private String accountNumber;
	    private double balance;

	    public Account(String accountNumber, double initialBalance) {
	        this.accountNumber = accountNumber;
	        this.balance = initialBalance;
	    }

	    public void deposit(double amount) {
	        balance += amount;
	        System.out.println("Deposited: Rs" + amount);
	    }

	    public void withdraw(double amount) {
	        if (balance >= amount) {
	            balance -= amount;
	            System.out.println("Withdrawn: Rs" + amount);
	        } else {
	            System.out.println("Insufficient funds");
	        }
	    }

	    public void checkBalance() {
	        System.out.println("Account Balance: Rs" + balance);
	    }

}
