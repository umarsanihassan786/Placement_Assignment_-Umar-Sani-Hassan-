package com.java.question5;

// normal need to implement all the methods of interface and abstract class

public class M extends B{
	public void a() {
		System.out.println("I am a");
	}

	public void b() {
		System.out.println("I am b");
	}

	public void d() {
		System.out.println("I am d");
	}
}
