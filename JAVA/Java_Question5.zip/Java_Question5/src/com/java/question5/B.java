package com.java.question5;

//An abstract class may or may not implement methods of interface it is implementing

abstract class B implements A{
	public void c() {
		System.out.println("I am C");
	}
}
