package com.java.question5;

public interface A {
	void a();//bydefault, public and abstract  
	void b();  
	void c();  
	void d();

}
