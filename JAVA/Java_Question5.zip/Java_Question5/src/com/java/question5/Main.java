package com.java.question5;

public class Main {

	public static void main(String[] args) {
		A a=new M();  // making an object of class M and storing in reference of type A
		a.a();  
		a.b();  
		a.c();  
		a.d();  
		}

	}
 //Difference between Interface and Abstract class

//Instantiation: An abstract class cannot be instantiated directly, whereas an interface cannot be instantiated at all.

//Method Implementation: An abstract class can have both abstract and non-abstract methods with implementations, while an interface can only have abstract methods without any implementation.

//Inheritance: A class can inherit from only one abstract class, but it can implement multiple interfaces.

//Variables: An abstract class can have member variables with different access modifiers, while an interface can only have constants (static final variables).

//Default Implementations: An abstract class can provide default implementations for its methods, but an interface cannot.

//Usage: Abstract classes are used when you want to provide a common base for a group of related classes, while interfaces are used when you want to define a contract that multiple unrelated classes can fulfill.



