package com.javaQuestion1;

public interface Shape {
	
	double calculateArea();
    double calculatePerimeter();

}
